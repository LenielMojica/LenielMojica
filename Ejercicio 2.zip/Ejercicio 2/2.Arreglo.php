<?php 
$AR = array("55","40","55","89","23","18","69","100","55","100");




foreach($AR as $key => $value)
{

    echo "$value &nbsp";

  
}
echo"<br><br>";
echo"Valor menor <br><br>";
echo "el valor menor es:", min($AR), "<br><br>";
echo"Valor mayor <br><br>";
echo "el valor mayor es:", max($AR),"<br><br>" ;
echo"Promedio  <br><br>";
echo "el promedio es: ", array_sum($AR), " entre ", count($AR), " = ",array_sum($AR)/ count($AR), "<br><br>" ;
echo"Mediana <br><br>";
echo sort($AR); foreach($AR as $key=>$value){
    echo"$value &nbsp";
}

echo "<br><br>La mediana es : 55+55/2= ", 55+55/2, "<br><br>" ;
echo"Moda <br><br>";
echo "La moda es: ", 55, " Y ", 100,"<br><br>";
echo"Rango <br><br>";
$Rango = max($AR)-min($AR);
echo "El rango es: ", $Rango;

?>